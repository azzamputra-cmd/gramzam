# ZAMGRAM — Panduan mulai dari HP

## Isi proyek
- `lib/main.dart`: aplikasi Flutter dan tampilan utama.
- `supabase/schema.sql`: struktur database dan aturan akses dasar.
- `.github/workflows/build-apk.yml`: build APK otomatis lewat GitHub Actions.

## Penting: status fitur
Ini adalah **starter project** yang sudah punya kerangka aplikasi, login/register Supabase, feed yang membaca tabel `posts`, profil dasar, dan navigasi Home/Explore/Reels/Chat/Profile dengan efek glass. Halaman Explore, Reels, dan Chat masih berupa kerangka UI; upload media, story viewer/filter, pencarian, dan chat realtime perlu disambungkan pada tahap berikutnya. Jangan menganggap semua fitur Instagram sudah selesai.

## 1. Siapkan Supabase
1. Buka https://supabase.com lalu buat project baru.
2. Buka Project Settings > API.
3. Salin Project URL dan `anon` / publishable key.
4. Buka `lib/main.dart`, ganti:
   - `https://YOUR_PROJECT_ID.supabase.co`
   - `YOUR_SUPABASE_ANON_KEY`
5. Jangan pernah memasukkan `service_role` key ke aplikasi Android.
6. Buka SQL Editor di Supabase, tempel isi `supabase/schema.sql`, lalu jalankan.
7. Untuk pendaftaran, buka Authentication > Providers > Email. Atur konfirmasi email sesuai kebutuhan.

## 2. Build APK dari HP memakai GitHub
Cara ini paling praktis jika lu hanya punya HP Android.
1. Install aplikasi GitHub atau buka https://github.com lewat browser.
2. Buat repository baru bernama `zamgram`.
3. Upload seluruh isi folder ZIP ini ke repository (bukan folder ZIP-nya).
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build ZAMGRAM APK** lalu tekan **Run workflow**.
6. Tunggu sampai proses selesai dengan tanda hijau.
7. Buka hasil workflow, cari bagian **Artifacts**, lalu unduh `zamgram-debug-apk`.
8. Ekstrak file artifact ZIP dan instal `app-debug.apk`.
9. Jika Android meminta izin instalasi dari sumber tersebut, aktifkan izin untuk browser/file manager yang dipakai.

## 3. Jika build gagal
- Pastikan semua file proyek sudah berada di root repository: `pubspec.yaml`, `lib/`, `android/`, `.github/`, dan `supabase/`.
- Cek log di GitHub Actions dan cari baris merah pertama.
- Pastikan workflow dijalankan dari branch yang berisi file proyek.

## Catatan
- APK debug untuk uji coba, bukan rilis Play Store.
- Feed hanya menampilkan postingan yang sudah ada di tabel `posts`.
- Untuk upload gambar/video, buat bucket Storage dan tambahkan implementasi upload.
- Chat membutuhkan pembuatan percakapan dan anggota percakapan; tabel dasarnya sudah disediakan.
- Story 24 jam memerlukan upload media, query story aktif, dan layar viewer.
- Integrasi Instagram/Meta tidak otomatis tersedia. Aplikasi ini punya backend sendiri dan tidak mengambil konten privat Instagram.
