import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = 'https://bhjyzhyzanlgqtomgyje.supabase.co';
const supabaseAnonKey = 'sb_publishable_6w2VKnNKvO_OvytDspSNAw_7bUiQI96';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final configured = !supabaseUrl.contains('YOUR_') && !supabaseAnonKey.contains('YOUR_');
  if (configured) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(ZamgramApp(connected: configured));
}

class ZamgramApp extends StatelessWidget {
  final bool connected;
  const ZamgramApp({super.key, required this.connected});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ZAMGRAM',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF080B14),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8A72FF), brightness: Brightness.dark),
      useMaterial3: true,
      fontFamily: 'Roboto',
    ),
    home: connected ? const AuthGate() : const SetupScreen(),
  );
}

class SetupScreen extends StatelessWidget {
  const SetupScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const BrandMark(),
        const SizedBox(height: 22),
        const Text('Hubungkan Supabase', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Text('Buka lib/main.dart lalu isi supabaseUrl dan supabaseAnonKey dari project Supabase lu.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.5)),
        const SizedBox(height: 18),
        const GlassPanel(child: Padding(padding: EdgeInsets.all(14), child: Text('Setelah URL dan anon key diisi, jalankan ulang aplikasi. Jangan pernah memasukkan service_role key ke aplikasi.', textAlign: TextAlign.center))),
      ]),
    )),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder(
    stream: Supabase.instance.client.auth.onAuthStateChange,
    builder: (context, snapshot) {
      final user = Supabase.instance.client.auth.currentUser;
      return user == null ? const AuthScreen() : const MainShell();
    },
  );
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final username = TextEditingController();
  bool register = false, busy = false;
  String message = '';
  Future<void> submit() async {
    setState(() { busy = true; message = ''; });
    try {
      final auth = Supabase.instance.client.auth;
      if (register) {
        final result = await auth.signUp(email: email.text.trim(), password: password.text);
        final user = result.user;
        if (user != null) {
          await Supabase.instance.client.from('profiles').upsert({
            'id': user.id, 'username': username.text.trim().isEmpty ? email.text.split('@').first : username.text.trim(),
            'display_name': username.text.trim().isEmpty ? 'Pengguna ZAMGRAM' : username.text.trim()
          });
        }
        message = 'Akun dibuat. Jika konfirmasi email aktif, cek email lu.';
      } else {
        await auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } on AuthException catch (e) { message = e.message; }
      catch (e) { message = 'Terjadi kesalahan: $e'; }
    if (mounted) setState(() { busy = false; });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(children: [
      const SizedBox(height: 35), const BrandMark(), const SizedBox(height: 12),
      const Text('Tempat cerita lu dimulai.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 34),
      GlassPanel(child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [
        Text(register ? 'Buat akun' : 'Selamat datang', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        if (register) input(username, 'Username', Icons.person_outline),
        input(email, 'Email', Icons.email_outlined),
        input(password, 'Password', Icons.lock_outline, obscure: true),
        if (message.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(message, style: const TextStyle(color: Colors.amber))),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: busy ? null : submit,
          child: Text(busy ? 'Tunggu...' : register ? 'Daftar' : 'Masuk'),
        )),
        TextButton(onPressed: () => setState(() { register = !register; message = ''; }), child: Text(register ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar')),
      ]))),
    ])))),
  );
  Widget input(TextEditingController c, String hint, IconData icon, {bool obscure = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 13),
    child: TextField(controller: c, obscureText: obscure, decoration: InputDecoration(prefixIcon: Icon(icon), hintText: hint, filled: true, fillColor: Colors.white.withOpacity(.06), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomeScreen(), ExploreScreen(), ReelsScreen(), ChatsScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
    extendBody: true,
    body: IndexedStack(index: index, children: pages),
    bottomNavigationBar: SafeArea(
      minimum: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      child: ClipRRect(borderRadius: BorderRadius.circular(26), child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
        child: Container(
          decoration: BoxDecoration(color: const Color(0xCC20243A), border: Border.all(color: Colors.white.withOpacity(.17)), borderRadius: BorderRadius.circular(26), boxShadow: [BoxShadow(color: Colors.deepPurple.withOpacity(.18), blurRadius: 25, offset: const Offset(0, 8))]),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            nav(Icons.home_rounded, 0), nav(Icons.search_rounded, 1), nav(Icons.play_circle_outline_rounded, 2), nav(Icons.chat_bubble_outline_rounded, 3), nav(Icons.person_outline_rounded, 4),
          ]),
        ),
      )),
    ),
  );
  Widget nav(IconData icon, int i) => IconButton(
    onPressed: () => setState(() => index = i),
    icon: Icon(icon, size: 25, color: index == i ? const Color(0xFFB7A8FF) : Colors.white60),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> posts = [];
  bool loading = true;
  @override
  void initState() { super.initState(); load(); }
  Future<void> load() async {
    try {
      final data = await Supabase.instance.client.from('posts').select('*, profiles(username, display_name, avatar_url)').order('created_at', ascending: false).limit(30);
      posts = List<Map<String, dynamic>>.from(data);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }
  @override
  Widget build(BuildContext context) => SafeArea(child: RefreshIndicator(
    onRefresh: load,
    child: CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 14), child: Row(children: [
        const Text('zamgram', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: -1.2)),
        const Spacer(), IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border_rounded)), IconButton(onPressed: () {}, icon: const Icon(Icons.add_box_outlined)),
      ]))),
      SliverToBoxAdapter(child: SizedBox(height: 112, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 14), children: [
        story('Cerita lu', null, own: true),
        for (final n in ['naya','raka','dimas','salsa','fajar','alika','bima']) story(n, 'https://i.pravatar.cc/150?img=${n.length * 7}'),
      ]))),
      if (loading) const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator())))
      else if (posts.isEmpty) const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(24), child: GlassPanel(child: Padding(padding: EdgeInsets.all(20), child: Text('Belum ada postingan. Buat postingan pertama lewat tombol + setelah fitur upload dihubungkan.')))))
      else SliverList(delegate: SliverChildBuilderDelegate((context, i) => PostCard(post: posts[i]), childCount: posts.length)),
      const SliverToBoxAdapter(child: SizedBox(height: 100)),
    ]),
  ));
  Widget story(String name, String? url, {bool own = false}) => Padding(padding: const EdgeInsets.symmetric(horizontal: 7), child: Column(children: [
    Container(padding: const EdgeInsets.all(2.5), decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: own ? [Colors.white24, Colors.white10] : [const Color(0xFFFF8A65), const Color(0xFF9B72FF), const Color(0xFF4DD0E1)])), child: CircleAvatar(radius: 31, backgroundColor: const Color(0xFF24283D), backgroundImage: url == null ? null : NetworkImage(url), child: url == null ? const Icon(Icons.add, size: 28) : null)),
    const SizedBox(height: 6), SizedBox(width: 68, child: Text(name, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11))),
  ]));
}

class PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  const PostCard({super.key, required this.post});
  @override
  State<PostCard> createState() => _PostCardState();
}
class _PostCardState extends State<PostCard> {
  bool liked = false;
  @override
  Widget build(BuildContext context) {
    final profile = widget.post['profiles'] as Map? ?? {};
    final image = widget.post['media_url']?.toString() ?? '';
    return Padding(padding: const EdgeInsets.only(bottom: 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(profile['username']?.toString() ?? 'user'), subtitle: const Text('ZAMGRAM'), trailing: const Icon(Icons.more_horiz)),
      if (image.isNotEmpty) AspectRatio(aspectRatio: 1, child: Image.network(image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF20243A), child: Center(child: Icon(Icons.image_not_supported))))),
      Row(children: [
        IconButton(onPressed: () => setState(() => liked = !liked), icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.pinkAccent : null)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.mode_comment_outlined)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.send_outlined)),
        const Spacer(), IconButton(onPressed: () {}, icon: const Icon(Icons.bookmark_border)),
      ]),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(widget.post['caption']?.toString() ?? '', style: const TextStyle(fontSize: 13))),
    ]));
  }
}

class ExploreScreen extends StatelessWidget {
  const ExploreScreen({super.key});
  @override
  Widget build(BuildContext context) => const SimplePage(title: 'Jelajahi', icon: Icons.search, message: 'Cari akun, teman, dan postingan ZAMGRAM. Fitur pencarian akan membaca data profil publik dari Supabase.');
}
class ReelsScreen extends StatelessWidget {
  const ReelsScreen({super.key});
  @override
  Widget build(BuildContext context) => const SimplePage(title: 'Reels', icon: Icons.play_circle_outline, message: 'Video pendek vertikal akan tampil di sini. Upload dan pemutaran video membutuhkan bucket Storage dan data reels di Supabase.');
}
class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key});
  @override
  Widget build(BuildContext context) => const SimplePage(title: 'Pesan', icon: Icons.chat_bubble_outline, message: 'Pesan pribadi realtime. Buat tabel conversations dan messages sesuai schema.sql, lalu hubungkan penerima pesan.');
}
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      Row(children: [const Text('Profil', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)), const Spacer(), IconButton(onPressed: () async => Supabase.instance.client.auth.signOut(), icon: const Icon(Icons.logout))]),
      const SizedBox(height: 25),
      const Center(child: CircleAvatar(radius: 48, backgroundColor: Color(0xFF35304F), child: Icon(Icons.person, size: 48))),
      const SizedBox(height: 12),
      Center(child: Text(user?.email?.split('@').first ?? 'pengguna', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20))),
      const Center(child: Text('Bio lu tampil di sini', style: TextStyle(color: Colors.white60))),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: const [Stat(value: '0', label: 'Postingan'), Stat(value: '0', label: 'Pengikut'), Stat(value: '0', label: 'Mengikuti')]),
      const SizedBox(height: 25),
      const GlassPanel(child: Padding(padding: EdgeInsets.all(16), child: Text('Grid postingan profil akan muncul di sini.'))),
    ]));
  }
}
class Stat extends StatelessWidget {
  final String value, label;
  const Stat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12))]);
}
class SimplePage extends StatelessWidget {
  final String title, message;
  final IconData icon;
  const SimplePage({super.key, required this.title, required this.icon, required this.message});
  @override
  Widget build(BuildContext context) => SafeArea(child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), const Spacer(),
    Center(child: Column(children: [Icon(icon, size: 76, color: const Color(0xFFB7A8FF)), const SizedBox(height: 18), Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, height: 1.6))])),
    const Spacer(),
  ])));
}
class BrandMark extends StatelessWidget {
  const BrandMark({super.key});
  @override
  Widget build(BuildContext context) => ShaderMask(shaderCallback: (r) => const LinearGradient(colors: [Color(0xFF6EE7F9), Color(0xFFB49AFF), Color(0xFFFF8DB5)]).createShader(r), child: const Text('ZAMGRAM', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 2, color: Colors.white)));
}
class GlassPanel extends StatelessWidget {
  final Widget child;
  const GlassPanel({super.key, required this.child});
  @override
  Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(24), child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18), child: Container(decoration: BoxDecoration(color: Colors.white.withOpacity(.075), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withOpacity(.14))), child: child)));
}
